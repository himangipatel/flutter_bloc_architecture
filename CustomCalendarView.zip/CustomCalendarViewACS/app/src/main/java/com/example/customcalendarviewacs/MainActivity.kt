package com.example.customcalendarviewacs

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import com.customcalendar.CEvents
import com.customcalendar.CalendarFragment
import com.customcalendar.day.DayEvent
import com.customcalendar.day.data.IEvent
import com.customcalendar.month.domain.Event
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val fragment = CalendarFragment()
        fragment.setCEventListener(object : CEvents {
            override fun onDateClick(date: String) {
                fragment.setDayEvents(getAllDayEvents())
            }

            override fun viewInitialised() {
                fragment.setDayEvents(getAllDayEvents())
                fragment.addEvents(getAllMonthEvents())
            }

            override fun onMonthSelected() {

            }

            override fun onDaySelected() {

            }
        })
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, fragment)
            .commitAllowingStateLoss()

    }

    private fun getAllDayEvents(): ArrayList<IEvent> {
        val events = ArrayList<IEvent>()
        run {
            val eventColor = ContextCompat.getColor(this, R.color.eventColor4)
            events.add(
                getEvent(
                    (8..10).random(), (0..60).random(), (11..15).random(), (0..60).random(),
                    "Front Desk - Supervisor" + UUID.randomUUID().toString(),
                    UUID.randomUUID().toString(), "Working", eventColor, R.drawable.ic_done
                )
            )
        }
        run {
            val eventColor = ContextCompat.getColor(this, R.color.eventColor1)
            events.add(
                getEvent(
                    (17..19).random(), (0..60).random(), (20..22).random(), (0..60).random(),
                    "Ticket Sales - Basketball" + UUID.randomUUID().toString(),
                    UUID.randomUUID().toString(), "Pending Swap", eventColor, R.drawable.ic_done
                )
            )
        }
        return events
    }

    private fun getAllMonthEvents(): List<Event> {
        val events = ArrayList<Event>()

        val currentCalender = Calendar.getInstance()
        currentCalender.set(Calendar.DAY_OF_MONTH, 1)
        currentCalender.set(Calendar.YEAR, 2021)
        currentCalender.set(Calendar.MONTH, Calendar.NOVEMBER)
        events.add(
            Event(
                Color.argb(255, 169, 68, 65),
                currentCalender.timeInMillis,
                "Event at " + Date(currentCalender.timeInMillis)
            )
        )
        events.add(
            Event(
                Color.argb(255, 169, 68, 65),
                currentCalender.timeInMillis,
                "Event at " + Date(currentCalender.timeInMillis)
            )
        )

        currentCalender.set(Calendar.DAY_OF_MONTH,5)
        events.add(
            Event(
                Color.argb(255, 169, 68, 65),
                currentCalender.timeInMillis,
                "Event at " + Date(currentCalender.timeInMillis)
            )
        )

        currentCalender.set(Calendar.MONTH,Calendar.DECEMBER)
        events.add(
            Event(
                Color.argb(255, 169, 68, 65),
                currentCalender.timeInMillis,
                "Event at " + Date(currentCalender.timeInMillis)
            )
        )
        return events
    }

    private fun getEvents(timeInMillis: Long, day: Int): List<Event> {
        return if (day < 2) {
            listOf(
                Event(
                    Color.argb(255, 169, 68, 65),
                    timeInMillis,
                    "Event at " + Date(timeInMillis)
                )
            )
        } else if (day in 3..4) {
            listOf(
                Event(
                    Color.argb(255, 169, 68, 65),
                    timeInMillis,
                    "Event at " + Date(timeInMillis)
                ),
                Event(
                    Color.argb(255, 100, 68, 65),
                    timeInMillis,
                    "Event 2 at " + Date(timeInMillis)
                )
            )
        } else {
            listOf(
                Event(
                    Color.argb(255, 169, 68, 65),
                    timeInMillis,
                    "Event at " + Date(timeInMillis)
                ),
                Event(
                    Color.argb(255, 100, 68, 65),
                    timeInMillis,
                    "Event 2 at " + Date(timeInMillis)
                ),
                Event(
                    Color.argb(255, 70, 68, 65),
                    timeInMillis,
                    "Event 3 at " + Date(timeInMillis)
                )
            )
        }
    }

    private fun getEvent(
        startHour: Int,
        startMin: Int,
        endHour: Int,
        endMin: Int,
        eventName: String,
        eventDescription: String,
        eventStatus: String,
        eventColor: Int,
        drawable: Int
    ): DayEvent {
        val timeStart = Calendar.getInstance()
        timeStart[Calendar.HOUR_OF_DAY] = startHour
        timeStart[Calendar.MINUTE] = startMin
        val timeEnd = timeStart.clone() as Calendar
        timeEnd[Calendar.HOUR_OF_DAY] = endHour
        timeEnd[Calendar.MINUTE] = endMin
        return DayEvent(
            1, timeStart, timeEnd, eventName,
            eventDescription, eventStatus, eventColor, drawable
        )
    }
}
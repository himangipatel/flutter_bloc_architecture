package com.customcalendar.horizontalcalendar

/**
 * Created by elf on 10,August,2020
 */
interface DateItemClickListener {
    fun onDateClick(date: String)
    fun updateMonth(month: String)
}
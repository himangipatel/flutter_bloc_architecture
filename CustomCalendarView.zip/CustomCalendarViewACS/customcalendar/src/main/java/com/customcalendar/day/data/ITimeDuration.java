package com.customcalendar.day.data;

import java.util.Calendar;

/**
 * Created by FRAMGIA\pham.van.khac on 8/24/16.
 */
public interface ITimeDuration {

    Calendar getStartTime();

    Calendar getEndTime();
}

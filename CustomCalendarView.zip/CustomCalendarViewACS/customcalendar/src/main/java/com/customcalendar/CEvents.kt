package com.customcalendar

interface CEvents {
    fun onDateClick(date: String)
    fun viewInitialised()
    fun onMonthSelected()
    fun onDaySelected()
}
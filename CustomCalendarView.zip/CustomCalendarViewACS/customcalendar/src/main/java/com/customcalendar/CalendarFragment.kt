package com.customcalendar

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.customcalendar.databinding.FragmentCalendarBinding
import com.customcalendar.day.DayEvent
import com.customcalendar.day.data.IEvent
import com.customcalendar.horizontalcalendar.DateItemClickListener
import com.customcalendar.month.CompactCalendarView
import com.customcalendar.month.domain.Event
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import androidx.appcompat.widget.PopupMenu


class CalendarFragment : Fragment(), DateItemClickListener {

    private lateinit var binding: FragmentCalendarBinding
    private val currentCalender = Calendar.getInstance(Locale.getDefault())
    private val dateFormatForDisplaying =
        SimpleDateFormat("dd-M-yyyy hh:mm:ss a", Locale.getDefault())
    private val dateFormatForMonth = SimpleDateFormat("MMMM, yyyy", Locale.getDefault())
    private var events: ArrayList<IEvent> = ArrayList()
    lateinit var cEvents: CEvents

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCalendarBinding.inflate(inflater, container, false)
        return binding.root
    }

    public fun setCEventListener(cEvents: CEvents){
        this.cEvents = cEvents
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initHorizontalCalendar()
        initCalendarMonth()
        initCalendayDay()
    }

    private fun initCalendayDay() {
        cEvents.viewInitialised()
        binding.tvDayMonth.setOnClickListener {

            val popup = PopupMenu(requireContext(), it)
            //Inflating the Popup using xml file
            //Inflating the Popup using xml file
            popup.menuInflater.inflate(R.menu.menu_calendar_type, popup.menu)

            //registering popup with OnMenuItemClickListener

            //registering popup with OnMenuItemClickListener
            popup.setOnMenuItemClickListener { item ->
                if (item.getTitle().equals("Today")){
                    binding.tvDayMonth.text = "Today"
                    binding.calendarMonth.visibility = View.GONE
                    binding.calendarDay.visibility = View.VISIBLE
                    binding.horizontalCalendar.visibility = View.VISIBLE
                } else {
                    binding.tvDayMonth.text = "Month"
                    binding.calendarMonth.visibility = View.VISIBLE
                    binding.calendarDay.visibility = View.GONE
                    binding.horizontalCalendar.visibility = View.GONE
                }
                true
            }

            popup.show()

        }

        binding.calendarDay.setLimitTime(8, 24)

        binding.calendarDay.setEvents(events)
    }

    fun setDayEvents(event: ArrayList<IEvent>){
        events.clear()
        events.addAll(event)
        binding.calendarDay.setEvents(events)
        /*run {
            val eventColor = ContextCompat.getColor(requireContext(), R.color.eventColor4)
            events.add(
                getEvent(
                    9, 0, 11, 30, "Front Desk - Supervisor",
                    "Hockaido", "Working", eventColor, R.drawable.ic_done
                )
            )
        }
        run {
            val eventColor = ContextCompat.getColor(requireContext(), R.color.eventColor1)
            events.add(
                getEvent(
                    13, 10, 14, 0, "Ticket Sales - Basketba...",
                    "Hockaido", "Pending Swap", eventColor, R.drawable.ic_done
                )
            )
        }*/
    }



    private fun initHorizontalCalendar() {
        binding.horizontalCalendar.initialize(this)
        binding.month.setOnClickListener {
            DatePickerDialog(
                requireContext(),
                binding.horizontalCalendar.dateSetListener,
                binding.horizontalCalendar.mCal.get(Calendar.YEAR),
                binding.horizontalCalendar.mCal.get(Calendar.MONTH),
                binding.horizontalCalendar.mCal.get(Calendar.DAY_OF_MONTH)
            ).show()
            binding.horizontalCalendar.mCal.add(Calendar.MONTH, -1)
        }
    }

    override fun onResume() {
        super.onResume()
        updateMonth(dateFormatForMonth.format(Date()));
    }

    private fun initCalendarMonth() {
        binding.calendarMonth.setUseThreeLetterAbbreviation(true)
        binding.calendarMonth.setFirstDayOfWeek(Calendar.MONDAY)
        binding.calendarMonth.setIsRtl(false)
        binding.calendarMonth.displayOtherMonthDays(true)

        binding.calendarMonth.invalidate()

        updateMonth(dateFormatForMonth.format(binding.calendarMonth.getFirstDayOfCurrentMonth()))
        updateMonth(dateFormatForMonth.format(binding.calendarMonth.getFirstDayOfCurrentMonth()))

        val mutableBookings: ArrayList<String> = ArrayList()
        val adapter: ArrayAdapter<*> =
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, mutableBookings)
        binding.calendarMonth.setListener(object : CompactCalendarView.CompactCalendarViewListener {
            override fun onDayClick(dateClicked: Date?) {
                updateMonth(dateFormatForMonth.format(dateClicked))
                val bookingsFromMap = binding.calendarMonth.getEvents(dateClicked)

                if (bookingsFromMap != null) {

                    mutableBookings.clear()
                    for (booking in bookingsFromMap) {
                        mutableBookings.add((booking.data as String?).toString())
                    }
                    adapter.notifyDataSetChanged()
                }
            }

            override fun onMonthScroll(firstDayOfNewMonth: Date?) {
                updateMonth(dateFormatForMonth.format(firstDayOfNewMonth))
            }
        })
        binding.calendarMonth.setAnimationListener(object :
            CompactCalendarView.CompactCalendarAnimationListener {
            override fun onOpened() {}
            override fun onClosed() {}
        })
    }


    fun addEvents(events: List<Event>) {
        binding.calendarMonth.addEvents(events)
    }

    private fun getEvents(timeInMillis: Long, day: Int): List<Event> {
        return when {
            day < 2 -> {
                listOf(
                    Event(
                        Color.argb(255, 169, 68, 65),
                        timeInMillis,
                        "Event at " + Date(timeInMillis)
                    )
                )
            }
            day in 3..4 -> {
                listOf(
                    Event(
                        Color.argb(255, 169, 68, 65),
                        timeInMillis,
                        "Event at " + Date(timeInMillis)
                    ),
                    Event(
                        Color.argb(255, 100, 68, 65),
                        timeInMillis,
                        "Event 2 at " + Date(timeInMillis)
                    )
                )
            }
            else -> {
                listOf(
                    Event(
                        Color.argb(255, 169, 68, 65),
                        timeInMillis,
                        "Event at " + Date(timeInMillis)
                    ),
                    Event(
                        Color.argb(255, 100, 68, 65),
                        timeInMillis,
                        "Event 2 at " + Date(timeInMillis)
                    ),
                    Event(
                        Color.argb(255, 70, 68, 65),
                        timeInMillis,
                        "Event 3 at " + Date(timeInMillis)
                    )
                )
            }
        }
    }

    private fun setToMidnight(calendar: Calendar) {
        calendar[Calendar.HOUR_OF_DAY] = 0
        calendar[Calendar.MINUTE] = 0
        calendar[Calendar.SECOND] = 0
        calendar[Calendar.MILLISECOND] = 0
    }


    override fun onDateClick(date: String) {
        cEvents.onDateClick(date)
    }

    override fun updateMonth(value: String) {
        Handler().postDelayed({
            binding.month.text = value
        }, 100)
    }
}
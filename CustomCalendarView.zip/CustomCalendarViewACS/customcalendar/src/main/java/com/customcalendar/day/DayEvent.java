package com.customcalendar.day;

import com.customcalendar.day.data.IEvent;

import java.util.Calendar;

/**
 * Created by FRAMGIA\pham.van.khac on 07/07/2016.
 */
public class DayEvent implements IEvent {

    private long mId;
    private Calendar mStartTime;
    private Calendar mEndTime;
    private String mName;
    private String mDescription;
    private String mStatus;
    private int mColor;
    private int mIcon;

    public DayEvent() {

    }

    public DayEvent(long mId, Calendar mStartTime, Calendar mEndTime, String mName, String mDescription,
                    String mStatus,
                    int mColor, int mIcon) {
        this.mId = mId;
        this.mStartTime = mStartTime;
        this.mEndTime = mEndTime;
        this.mName = mName;
        this.mDescription = mDescription;
        this.mStatus = mStatus;
        this.mColor = mColor;
        this.mIcon = mIcon;
    }

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        this.mId = id;
    }

    public Calendar getStartTime() {
        return mStartTime;
    }

    public void setStartTime(Calendar startTime) {
        this.mStartTime = startTime;
    }

    public Calendar getEndTime() {
        return mEndTime;
    }

    public void setEndTime(Calendar endTime) {
        this.mEndTime = endTime;
    }

    public String getName() {
        return mName;
    }

    @Override
    public String getStatus() {
        return mStatus;
    }

    public void setName(String name) {
        this.mName = name;
    }


    public int getColor() {
        return mColor;
    }

    @Override
    public int getIcon() {
        return mIcon;
    }

    @Override
    public String getDescription() {
        return mDescription;
    }

    public void setColor(int color) {
        this.mColor = color;
    }
}

package com.customcalendar.day.decoration;

import android.content.Context;
import android.graphics.Rect;


import com.customcalendar.day.DayView;
import com.customcalendar.day.EventView;
import com.customcalendar.day.data.IEvent;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by FRAMGIA\pham.van.khac on 22/07/2016.
 */
public class CdvDecorationDefault implements CdvDecoration {

    protected Context mContext;

    protected EventView.OnEventClickListener mEventClickListener;


    public CdvDecorationDefault(Context context) {
        this.mContext = context;
    }

    @Override
    public EventView getEventView(IEvent event, Rect eventBound, int hourHeight,
                                  int separateHeight) {
        EventView eventView = new EventView(mContext);
        eventView.setEvent(event);
        eventView.setPosition(eventBound, -hourHeight, hourHeight - separateHeight * 2);
        eventView.setOnEventClickListener(mEventClickListener);
        return eventView;
    }


    @Override
    public DayView getDayView(int hour) {
        DayView dayView = new DayView(mContext);
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm aa");
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, 0);
        dayView.setText(sdf.format(calendar.getTime()));
        return dayView;
    }

    public void setOnEventClickListener(EventView.OnEventClickListener listener) {
        this.mEventClickListener = listener;
    }


}
